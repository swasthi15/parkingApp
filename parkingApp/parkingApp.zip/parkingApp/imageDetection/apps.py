from django.apps import AppConfig


class ImagedetectionConfig(AppConfig):
    name = 'imageDetection'
